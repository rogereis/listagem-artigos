/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.pesdoc.dao;

import br.com.pesdoc.model.CrudModel;
import br.com.pesdoc.model.UsuarioModel;
import br.com.topsys.database.TSDataBaseBrokerIf;
import br.com.topsys.database.factory.TSDataBaseBrokerFactory;
import br.com.topsys.exception.TSApplicationException;
import br.com.topsys.util.TSUtil;
import java.util.List;

/**
 *
 * @author roque souza
 */
public final class UsuarioDAO implements CrudDAO {

  public UsuarioModel obterAcesso(final UsuarioModel model) {

    TSDataBaseBrokerIf broker = TSDataBaseBrokerFactory.getDataBaseBrokerIf();

    broker.setPropertySQL("usuariodao.obterAcesso", model.getLogin(), model.getSenha());

    return (UsuarioModel) broker.getObjectBean(UsuarioModel.class, "id", "nome", "login", "flagAtivo", "email");

  }

  public UsuarioModel obterPorLoginSenha(UsuarioModel model) {

    TSDataBaseBrokerIf broker = TSDataBaseBrokerFactory.getDataBaseBrokerIf();

    broker.setPropertySQL("usuariodao.obterporloginsenha", model.getLogin(), model.getSenha());

    return (UsuarioModel) broker.getObjectBean(UsuarioModel.class, "id", "login", "senha");

  }

  public void alterarSenha(UsuarioModel model) throws TSApplicationException {

    TSDataBaseBrokerIf broker = TSDataBaseBrokerFactory.getDataBaseBrokerIf();

    broker.setPropertySQL("usuariodao.alterarsenha", model.getSenha(), model.getLogin());

    broker.execute();

  }

  @Override
  public List<CrudModel> pesquisar(CrudModel crudModel) {
    UsuarioModel model = (UsuarioModel) crudModel;
    TSDataBaseBrokerIf broker = TSDataBaseBrokerFactory.getDataBaseBrokerIf();

    if (!TSUtil.isEmpty(model.getNome())) {
      model.setNome(model.getNome() + "%");
    }

    broker.setPropertySQL("usuariodao.pesquisar", model.getNome(), model.getLogin(), model.getFlagAtivo());

    return broker.getCollectionBean(UsuarioModel.class, "id", "nome", "login", "flagAtivo", "email");
  }

  @Override
  public CrudModel obter(CrudModel crudModel) {
    UsuarioModel model = (UsuarioModel) crudModel;

    TSDataBaseBrokerIf broker = TSDataBaseBrokerFactory.getDataBaseBrokerIf();

    broker.setPropertySQL("usuariodao.obter", model.getId());

    return (UsuarioModel) broker.getObjectBean(UsuarioModel.class, "id", "nome", "login", "senha", "flagAtivo", "email");
  }

  @Override
  public CrudModel inserir(CrudModel crudModel) throws TSApplicationException {
    UsuarioModel model = (UsuarioModel) crudModel;
    TSDataBaseBrokerIf broker = TSDataBaseBrokerFactory.getDataBaseBrokerIf();

    model.setId(broker.getSequenceNextValue("usuario_id_seq"));

    broker.setPropertySQL("usuariodao.inserir", model.getId(), model.getNome(), model.getLogin(), model.getSenha(), model.getFlagAtivo(), model.getEmail());

    broker.execute();

    return model;
  }

  @Override
  public void alterar(CrudModel crudModel) throws TSApplicationException {
    UsuarioModel model = (UsuarioModel) crudModel;
    TSDataBaseBrokerIf broker = TSDataBaseBrokerFactory.getDataBaseBrokerIf();

    broker.setPropertySQL("usuariodao.alterar", model.getNome(), model.getLogin(), model.getSenha(), model.getFlagAtivo(), model.getEmail(), model.getId());

    broker.execute();
  }

  @Override
  public void excluir(CrudModel crudModel) throws TSApplicationException {
    UsuarioModel model = (UsuarioModel) crudModel;
    TSDataBaseBrokerIf broker = TSDataBaseBrokerFactory.getDataBaseBrokerIf();

    broker.setPropertySQL("usuariodao.excluir", model.getId());

    broker.execute();
  }
}
