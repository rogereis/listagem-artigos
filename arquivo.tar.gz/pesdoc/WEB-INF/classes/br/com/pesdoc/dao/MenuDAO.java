/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.pesdoc.dao;

import br.com.pesdoc.model.MenuModel;
import br.com.pesdoc.util.Utilitario;
import br.com.topsys.database.TSDataBaseBrokerIf;
import br.com.topsys.database.factory.TSDataBaseBrokerFactory;
import br.com.topsys.exception.TSApplicationException;
import java.util.List;

/**
 *
 * @author roque souza
 */
public final class MenuDAO {



  public List<MenuModel> pesquisarMenuRaizAdm() {

    TSDataBaseBrokerIf broker = TSDataBaseBrokerFactory.getDataBaseBrokerIf();

    broker.setPropertySQL("menudao.pesquisarmenuraizadm");

    return broker.getCollectionBean(MenuModel.class, "id", "descricao", "url", "menuModel.id");

  }

  public List<MenuModel> pesquisarMenuCommandAdm() {

    TSDataBaseBrokerIf broker = TSDataBaseBrokerFactory.getDataBaseBrokerIf();

    broker.setPropertySQL("menudao.pesquisarmenucommandadm");

    return broker.getCollectionBean(MenuModel.class, "id", "descricao", "url", "menuModel.id", "menuModel.descricao", "managedBean", "ordem", "flagInserir", "flagAlterar", "flagExcluir");

  }

}
