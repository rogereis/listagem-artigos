/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.pesdoc.dao;

import br.com.pesdoc.model.CrudModel;
import br.com.pesdoc.model.DocumentoModel;
import br.com.pesdoc.util.Utilitario;
import br.com.topsys.database.TSDataBaseBrokerIf;
import br.com.topsys.database.factory.TSDataBaseBrokerFactory;
import br.com.topsys.exception.TSApplicationException;
import br.com.topsys.util.TSUtil;
import java.util.List;
import java.util.StringTokenizer;

/**
 *
 * @author roquesouza
 */
public final class DocumentoDAO implements CrudDAO {

  @Override
  public DocumentoModel obter(final CrudModel crudModel) {

    DocumentoModel model = (DocumentoModel) crudModel;

    TSDataBaseBrokerIf broker = TSDataBaseBrokerFactory.getDataBaseBrokerIf();

    broker.setPropertySQL("documentodao.obter", model.getId());

    return (DocumentoModel) broker.getObjectBean(DocumentoModel.class, "id", "arquivo", "titulo", "resumo", "texto", "dataDocumento", "dataCadastro", "flagAtivo");

  }

  @Override
  public List<CrudModel> pesquisar(final CrudModel crudModel) {

    DocumentoModel model = (DocumentoModel) crudModel;

    TSDataBaseBrokerIf broker = TSDataBaseBrokerFactory.getDataBaseBrokerIf();

    broker.setPropertySQL("documentodao.pesquisar", "%"+Utilitario.tratarString(model.getTitulo())+"%", model.getFlagAtivo());

    return broker.getCollectionBean(DocumentoModel.class, "id", "arquivo", "titulo", "resumo", "texto", "dataDocumento", "dataCadastro", "flagAtivo");

  }

  public List<DocumentoModel> pesquisarDocumento(final CrudModel crudModel) {

    DocumentoModel model = (DocumentoModel) crudModel;

    TSDataBaseBrokerIf broker = TSDataBaseBrokerFactory.getDataBaseBrokerIf();

    broker.setPropertySQL("documentodao.pesquisar", Utilitario.tratarString(model.getTitulo()), model.getFlagAtivo());

    return broker.getCollectionBean(DocumentoModel.class, "id", "arquivo", "titulo", "resumo", "texto", "dataDocumento", "dataCadastro", "flagAtivo");

  }

  public List<DocumentoModel> pesquisarTextos(final CrudModel crudModel) {

    DocumentoModel model = (DocumentoModel) crudModel;

    TSDataBaseBrokerIf broker = TSDataBaseBrokerFactory.getDataBaseBrokerIf();

    StringTokenizer texto = new StringTokenizer(Utilitario.tratarString(model.getTitulo()));
    String filtro = "";

    while (texto.hasMoreTokens()) {
      filtro += texto.nextToken();
      if (texto.hasMoreTokens()) {
        filtro += "|";
      }
    }

    broker.setPropertySQL("documentodao.pesquisartextos", filtro, filtro);

    return broker.getCollectionBean(DocumentoModel.class, "id", "arquivo", "titulo", "resumo", "texto", "dataDocumento");

  }

  @Override
  public DocumentoModel inserir(final CrudModel crudModel) throws TSApplicationException {

    DocumentoModel model = (DocumentoModel) crudModel;

    TSDataBaseBrokerIf broker = TSDataBaseBrokerFactory.getDataBaseBrokerIf();

    model.setId(broker.getSequenceNextValue("documento_id_seq"));

    broker.setPropertySQL("documentodao.inserir", model.getId(), model.getArquivo(), model.getTitulo(), model.getResumo(), model.getTexto(), model.getDataDocumento(), model.getFlagAtivo());

    broker.execute();

    return model;

  }

  @Override
  public void alterar(final CrudModel crudModel) throws TSApplicationException {

    DocumentoModel model = (DocumentoModel) crudModel;

    TSDataBaseBrokerIf broker = TSDataBaseBrokerFactory.getDataBaseBrokerIf();

    broker.setPropertySQL("documentodao.alterar", model.getArquivo(), model.getTitulo(), model.getResumo(), model.getTexto(), model.getDataDocumento(), model.getFlagAtivo(), model.getId());

    broker.execute();

  }

  @Override
  public void excluir(final CrudModel crudModel) throws TSApplicationException {

    DocumentoModel model = (DocumentoModel) crudModel;

    TSDataBaseBrokerIf broker = TSDataBaseBrokerFactory.getDataBaseBrokerIf();

    broker.setPropertySQL("documentodao.excluir", model.getId());

    broker.execute();

  }
}
