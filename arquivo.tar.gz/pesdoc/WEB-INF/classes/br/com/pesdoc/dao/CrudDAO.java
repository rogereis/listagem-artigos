/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.pesdoc.dao;

import br.com.pesdoc.model.CrudModel;
import br.com.topsys.exception.TSApplicationException;
import java.util.List;

/**
 *
 * @author roquesouza
 */
public interface CrudDAO {
  
  public CrudModel inserir(final CrudModel crudModel) throws TSApplicationException ;
  public List<CrudModel> pesquisar(final CrudModel crudModel);
  public CrudModel obter(final CrudModel crudModel);
  public void alterar(final CrudModel crudModel) throws TSApplicationException ;
  public void excluir(final CrudModel crudModel) throws TSApplicationException ;
  
}
