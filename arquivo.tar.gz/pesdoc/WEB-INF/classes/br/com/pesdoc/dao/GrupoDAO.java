/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.pesdoc.dao;


import br.com.pesdoc.model.CrudModel;
import br.com.pesdoc.model.GrupoModel;
import br.com.pesdoc.util.Utilitario;
import br.com.topsys.database.TSDataBaseBrokerIf;
import br.com.topsys.database.factory.TSDataBaseBrokerFactory;
import br.com.topsys.exception.TSApplicationException;
import java.util.List;

/**
 *
 * @author roquesouza
 */
public final class GrupoDAO implements CrudDAO {

  @Override
  public GrupoModel obter(final CrudModel crudModel) {

      GrupoModel model = (GrupoModel) crudModel;
      
      TSDataBaseBrokerIf broker = TSDataBaseBrokerFactory.getDataBaseBrokerIf();

      broker.setPropertySQL("grupodao.obter", model.getId());

      return (GrupoModel) broker.getObjectBean(GrupoModel.class, "id", "descricao", "flagAtivo");

  }

  @Override
  public List<CrudModel> pesquisar(final CrudModel crudModel) {

    GrupoModel model = (GrupoModel) crudModel;

    TSDataBaseBrokerIf broker = TSDataBaseBrokerFactory.getDataBaseBrokerIf();

    broker.setPropertySQL("grupodao.pesquisar", Utilitario.tratarString(model.getDescricao()), model.getFlagAtivo());

    return broker.getCollectionBean(GrupoModel.class, "id", "descricao", "flagAtivo");

  }
    
  public List<GrupoModel> pesquisarGrupo(final CrudModel crudModel) {

    GrupoModel model = (GrupoModel) crudModel;

    TSDataBaseBrokerIf broker = TSDataBaseBrokerFactory.getDataBaseBrokerIf();

    broker.setPropertySQL("grupodao.pesquisar", Utilitario.tratarString(model.getDescricao()), model.getFlagAtivo());

    return broker.getCollectionBean(GrupoModel.class, "id", "descricao", "flagAtivo");

  }

  @Override
  public GrupoModel inserir(final CrudModel crudModel) throws TSApplicationException {

    GrupoModel model = (GrupoModel) crudModel;
    
    TSDataBaseBrokerIf broker = TSDataBaseBrokerFactory.getDataBaseBrokerIf();
    
    broker.beginTransaction();

    model.setId(broker.getSequenceNextValue("grupo_id_seq"));

    broker.setPropertySQL("grupodao.inserir", model.getId(), model.getDescricao(), model.getFlagAtivo());

    broker.execute();
    
    broker.endTransaction();

    return model;

  }

  @Override
  public void alterar(final CrudModel crudModel) throws TSApplicationException {
    
    GrupoModel model = (GrupoModel) crudModel;

    TSDataBaseBrokerIf broker = TSDataBaseBrokerFactory.getDataBaseBrokerIf();
    
    broker.beginTransaction();

    broker.setPropertySQL("grupodao.alterar", model.getDescricao(), model.getFlagAtivo(), model.getId());

    broker.execute();

    broker.endTransaction();

  }

  @Override
  public void excluir(final CrudModel crudModel) throws TSApplicationException {
    
    GrupoModel model = (GrupoModel) crudModel;

    TSDataBaseBrokerIf broker = TSDataBaseBrokerFactory.getDataBaseBrokerIf();

    broker.setPropertySQL("grupodao.excluir", model.getId());

    broker.execute();

  }
}
