/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.pesdoc.util;

import br.com.pesdoc.model.UsuarioModel;
import br.com.topsys.exception.TSSystemException;
import br.com.topsys.util.TSUtil;
import br.com.topsys.web.util.TSFacesUtil;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.util.PDFTextStripper;
import java.io.File;
import java.io.IOException;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

/**
 *
 * @author roque souza
 */
public class Utilitario {

  public static boolean addErrorMessageObrigatorio(String campo) {
    TSFacesUtil.addErrorMessage(campo + ": este valor é obrigatório.");
    return false;
  }

  public static boolean addErrorMessageObrigatorio(String campo, String destino) {
    TSFacesUtil.addErrorMessage(destino, campo + ": este valor é obrigatório.");
    return false;
  }

  public static boolean addWarningMessageObrigatorio(String campo, String destino) {
    FacesContext.getCurrentInstance().addMessage(destino, new FacesMessage(FacesMessage.SEVERITY_WARN, null, campo + ": este valor é obrigatório."));
    return false;
  }

  public static boolean addWarningMessage(String frase, String destino) {
    FacesContext.getCurrentInstance().addMessage(destino, new FacesMessage(FacesMessage.SEVERITY_WARN, null, frase));
    return false;
  }
  
  public static boolean addWarningMessage(String frase) {
    FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, null, frase));
    return false;
  }

  public static String tratarString(String valor) {

    if (!TSUtil.isEmpty(valor)) {

      valor = valor.trim().replaceAll("  ", " ");

      if (valor.equalsIgnoreCase("")) {
        valor = null;
      }

    } else {
      valor = null;
    }

    return valor;
  }

  public static UsuarioModel getUsuarioLogado() {

    UsuarioModel usuario = null;

    try {

      usuario = (UsuarioModel) TSFacesUtil.getObjectInSession(Constantes.USUARIO_LOGADO);

    } catch (Exception e) {

      e.printStackTrace();

    }

    return usuario;



  }

  public static Double tratarDouble(Double valor) {

    if (TSUtil.isEmpty(valor) || valor.equals(0D)) {
      return null;

    }

    return valor;

  }

  public static Long tratarLong(Long valor) {

    if (TSUtil.isEmpty(valor) || valor.equals(0L)) {
      return null;

    }

    return valor;

  }

  /*public static String getCaminhoRelatorio() {
    return FacesContext.getCurrentInstance().getExternalContext().getRealPath("WEB-INF" + File.separator + Constantes.PASTA_RELATORIO + File.separator) + File.separator;
  }*/
  
  /*public static String getCaminhoRelatorio() {
    return "d:" + File.separator;
  }*/

  public static String getCaminhoRelatorio() {
    return "/arquivos/pesdoc/";
  }
  
  public static String getPdfMetaData(String pathFile) {
    PDDocument document = null;
    PDFTextStripper text = null;

    try {
      document = PDDocument.load(new File(pathFile));

      text = new PDFTextStripper();

      return text.getText(document);


    } catch (Exception e) {
    	    	
      System.out.println("Arquivo " + pathFile + " importado com erro.");

      throw new TSSystemException(e);

    } finally {
      try {
        document.close();
      } catch (IOException e) {
      }
    }
  }

}
