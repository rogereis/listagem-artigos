/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.pesdoc.util;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import sun.misc.BASE64Encoder;

/**
 *
 * @author roque souza
 */
public class EncriptaSenha {

  public static String encriptar(String senha) throws NoSuchAlgorithmException {
      MessageDigest digest = MessageDigest.getInstance("MD5");
      digest.update(senha.getBytes());
      BASE64Encoder encoder = new BASE64Encoder();
      return encoder.encode(digest.digest());    
  }
}
