package br.com.pesdoc.util;

import java.io.File;
import java.io.IOException;

import br.com.topsys.exception.TSSystemException;
import br.com.topsys.file.TSFile;

public class ProcessaPdf {		

	public ProcessaPdf() {
		
	}

	// -density 300x300 
	public String processar(String caminhoPdf){
		String retorno = null;
		StringBuilder sb = new StringBuilder();
		sb.append("convert ").append(caminhoPdf).append(" ").append(caminhoPdf).append(".tiff");
		try {
		
			Runtime.getRuntime().exec(sb.toString());
			
			this.executarTesseract(caminhoPdf+".tiff");
			
			retorno = this.lerArquivoTxt(caminhoPdf+".txt");
			
			this.deletarArquivo(caminhoPdf);
			
		
		} catch (IOException e) {
			throw new TSSystemException(e);
		}
		
		return retorno;
	}

	private boolean isWindows() {

		String os = System.getProperty("os.name").toLowerCase();
		return (os.indexOf("win") >= 0);

	}	
	
	private void executarTesseract(String nomeTiff){
		StringBuilder sb = null;
		try {
			sb = new StringBuilder();
			
			if (isWindows()){
				
				sb.append("tesseract.exe ");
				sb.append(nomeTiff);
				sb.append(" -l por");
				
				Runtime.getRuntime().exec(sb.toString());

			}else{
				
				sb.append("tesseract ");
				sb.append(nomeTiff);
				sb.append(" -l por");
				
				Runtime.getRuntime().exec(sb.toString());
			}	
		} catch (IOException e) {
			throw new TSSystemException(e);
		}
	}
	
	private String lerArquivoTxt(String nomeTxt){
		TSFile file = new TSFile();
		file.openFile(nomeTxt);
		return file.readAllFile();
	}
	
	private void deletarArquivo(String nomePdf){
		new File(nomePdf+".txt").delete();
		new File(nomePdf+".tiff").delete();
		
	}
	
	public static void main(String[] args) {
		new ProcessaPdf();
	}


}
