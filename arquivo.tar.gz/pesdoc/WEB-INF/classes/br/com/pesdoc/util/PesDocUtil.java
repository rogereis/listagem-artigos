package br.com.pesdoc.util;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Date;

import javax.faces.application.FacesMessage;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.util.PDFTextStripper;
import org.apache.poi.POITextExtractor;
import org.apache.poi.extractor.ExtractorFactory;
import org.primefaces.model.UploadedFile;

import br.com.topsys.exception.TSApplicationException;
import br.com.topsys.exception.TSSystemException;
import br.com.topsys.file.TSFile;
import br.com.topsys.util.TSDateUtil;
import br.com.topsys.util.TSParseUtil;
import br.com.topsys.util.TSUtil;

public class PesDocUtil {

	private static final int DEFAULT_BUFFER_SIZE = 10240;

	private PesDocUtil() {

	}

	public static String[] getVetor(String... parameters) {

		String[] vetor = null;

		if (!TSUtil.isEmpty(parameters)) {

			vetor = new String[parameters.length];
			int i = 0;

			for (String str : parameters) {

				vetor[i] = str;
				i++;

			}

		}

		return vetor;

	}

	public static void addErrorMessage(String msg) {
		FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "ERRO", msg));
	}

	public static void addInfoMessage(String msg) {
		FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "INFO", msg));
	}

	public static void addWarnMessage(String msg) {
		FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "AVISO", msg));
	}

	public static String tratarString(String str) {
		return (str == null) ? "%" : "%" + str.toLowerCase() + "%";
	}


	public static String obterNomeArquivo(UploadedFile file) {

		if (TSUtil.isEmpty(file)) {
			return null;
		}

		if (file.getFileName().contains("\\")) {

			String[] fileName = file.getFileName().split("\\\\");

			return fileName[fileName.length - 1];

		} else {

			return file.getFileName();

		}
	}


	public static String getDescricaoPDF(UploadedFile event) {
		try {
			return getText(event.getInputstream());
		} catch (IOException e) {
			new TSApplicationException(e);
		}
		return null;
	}

	public static String getText(InputStream stream) {
		PDDocument document = null;
		PDFTextStripper text = null;

		try {
			document = PDDocument.load(stream);

			text = new PDFTextStripper();

			return text.getText(document);

		} catch (Exception e) {

			throw new TSSystemException(e);

		} finally {
			try {
				document.close();
			} catch (IOException e) {
			}
		}
	}

	public static String getDescricaoOffice(UploadedFile event) {

		byte[] utf8 = null;

		try {

			if (extensaoOfficeValida(TSFile.obterExtensaoArquivo(event.getFileName()))) {

				POITextExtractor ex = ExtractorFactory.createExtractor(event.getInputstream());

				if (!TSUtil.isEmpty(ex)) {
					utf8 = ex.getText().getBytes("UTF-8");
				}

			}

		} catch (Exception e) {

			new TSApplicationException(e);

		}

		String s = null;
		if (!TSUtil.isEmpty(utf8)) {
			s = new String(utf8);
		}

		return s;

	}

	public static String getDescricaoOffice(File event) {

		byte[] utf8 = null;

		try {

			if (extensaoOfficeValida(TSFile.obterExtensaoArquivo(event.getName()))) {

				POITextExtractor ex = ExtractorFactory.createExtractor(event);

				if (!TSUtil.isEmpty(ex)) {
					utf8 = ex.getText().getBytes("UTF-8");
				}

			}

		} catch (Exception e) {

			new TSApplicationException(e);

		}

		String s = null;
		if (!TSUtil.isEmpty(utf8)) {
			s = new String(utf8);
		}

		return s;

	}

	public static boolean extensaoOfficeValida(String extensao) {
		return ".DOC".equalsIgnoreCase(extensao) || ".DOCX".equalsIgnoreCase(extensao) || ".XLS".equalsIgnoreCase(extensao) || ".XLSX".equalsIgnoreCase(extensao) || ".PPT".equalsIgnoreCase(extensao) || ".PPTX".equalsIgnoreCase(extensao);
	}
	
	public static boolean extensaoVisivel(String extensao) {
		return ".DOC".equalsIgnoreCase(extensao) || ".DOCX".equalsIgnoreCase(extensao) || ".XLS".equalsIgnoreCase(extensao) || ".XLSX".equalsIgnoreCase(extensao) || ".PPT".equalsIgnoreCase(extensao) || ".PPTX".equalsIgnoreCase(extensao) ||
			   ".PDF".equalsIgnoreCase(extensao) || ".JPEG".equalsIgnoreCase(extensao) || ".JPG".equalsIgnoreCase(extensao) || ".PNG".equalsIgnoreCase(extensao) || ".TXT".equalsIgnoreCase(extensao) || ".RTF".equalsIgnoreCase(extensao) || ".GIF".equalsIgnoreCase(extensao);
	}

	public static String getAnoMes(Date data) {

		if (!TSUtil.isEmpty(data)) {

			return TSParseUtil.dateToString(data, TSDateUtil.YYYY) + File.separator + TSParseUtil.dateToString(data, TSDateUtil.MM) + File.separator;

		} else {

			return null;

		}

	}

	public static void criaArquivo(InputStream file, String arquivo) {

		try {
			FileUtils.copyInputStreamToFile(file, new File(arquivo));
		} catch (Exception ex) {
			throw new TSSystemException(ex);
		}

	}

	public static void criaArquivo(UploadedFile file, String arquivo) {
		try {
			criaArquivo(file.getInputstream(), arquivo);
		} catch (IOException e) {
			throw new TSSystemException(e);
		}
	}

	public static void download(String arquivo) throws IOException {

		// Prepare.
		FacesContext facesContext = FacesContext.getCurrentInstance();
		ExternalContext externalContext = facesContext.getExternalContext();
		HttpServletResponse response = (HttpServletResponse) externalContext.getResponse();

		File file = new File(arquivo);
		BufferedInputStream input = null;
		BufferedOutputStream output = null;

		try {
			// Open file.
			input = new BufferedInputStream(new FileInputStream(file), DEFAULT_BUFFER_SIZE);

			// Init servlet response.
			response.reset();
			response.setHeader("Content-Type", "multipart/form-data");
			response.setHeader("Content-Length", String.valueOf(file.length()));
			response.setHeader("Content-Disposition", "attachment; filename=\"" + file.getName() + "\"");
			output = new BufferedOutputStream(response.getOutputStream(), DEFAULT_BUFFER_SIZE);

			// Write file contents to response.
			byte[] buffer = new byte[DEFAULT_BUFFER_SIZE];
			int length;
			while ((length = input.read(buffer)) > 0) {
				output.write(buffer, 0, length);
			}

			// Finalize task.
			output.flush();
		} finally {
			// Gently close streams.
			close(output);
			close(input);
		}

		facesContext.responseComplete();
	}

	private static void close(Closeable resource) {
		if (resource != null) {
			try {
				resource.close();
			} catch (IOException e) {

				e.printStackTrace();
			}
		}
	}

	public static String getPdfMetaData(String pathFile) {
		PDDocument document = null;
		PDFTextStripper text = null;

		try {
			document = PDDocument.load(new File(pathFile));

			text = new PDFTextStripper();

			return text.getText(document);

		} catch (Exception e) {

			System.out.println("Arquivo " + pathFile + " importado com erro.");

			throw new TSSystemException(e);

		} finally {
			try {
				document.close();
			} catch (IOException e) {
			}
		}
	}

}
