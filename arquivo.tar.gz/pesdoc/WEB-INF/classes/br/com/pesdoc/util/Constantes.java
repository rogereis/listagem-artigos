/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package br.com.pesdoc.util;

/**
 *
 * @author roque souza
 */
public final class Constantes {
  
  public static final String ERRO_VALIDACAO = "erroValidacao"; 
  public static final String USUARIO_LOGADO = "usuarioLogado";
  public static final String LOGIN = "login";
  public static final String IMAGEM_BANNER = "resources/images/bannerHF.jpg";
  public static final String PASTA_RELATORIO = "relatorios";
  

}
