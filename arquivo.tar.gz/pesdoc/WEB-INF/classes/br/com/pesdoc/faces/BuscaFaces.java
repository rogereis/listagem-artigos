package br.com.pesdoc.faces;

import br.com.pesdoc.dao.DocumentoDAO;
import br.com.pesdoc.model.DocumentoModel;
import br.com.pesdoc.util.Utilitario;
import br.com.topsys.util.TSUtil;
import br.com.topsys.web.faces.TSMainFaces;
import br.com.topsys.web.util.TSFacesUtil;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletResponse;

/**
 * 
 * @author roquesouza
 */
@ManagedBean(name = "buscaFaces")
@SessionScoped
public final class BuscaFaces extends TSMainFaces {

	private DocumentoDAO documentoDAO;
	private DocumentoModel documentoPesquisaModel;
	private List<DocumentoModel> grid;
	private static final int DEFAULT_BUFFER_SIZE = 10240; // 10KB.
	private String link;

	public BuscaFaces() {
		this.documentoDAO = new DocumentoDAO();
		this.clearFields();
	}

	@Override
	protected void clearFields() {
		
		this.documentoPesquisaModel = new DocumentoModel();
		this.grid = new ArrayList<DocumentoModel>();
		
	}

	private boolean validaCampos() {

		boolean validacao = true;

		if (TSUtil.isEmpty(documentoPesquisaModel.getTitulo())) {
			
			validacao = Utilitario.addWarningMessage("Preencha um critério para a busca.");
			
		}

		return validacao;
	}

	public void carregarLink() {
		
		link = TSFacesUtil.getRequest().getRequestURL().toString();
		
		link = link.replace("index", "download");
		
		link = link + "?id=" + this.documentoPesquisaModel.getId();
		

	}

	public String pesquisarTextos() {

		if (validaCampos()) {

			this.grid = documentoDAO.pesquisarTextos(this.documentoPesquisaModel);

			if (this.grid.isEmpty()) {
				TSFacesUtil.addInfoMessage("A pesquisa não retornou ocorrência.");
			}

		}

		return "sucessoBusca";
	}

	public void atualizaTela() {

	}

	public DocumentoModel getDocumentoPesquisaModel() {
		return documentoPesquisaModel;
	}

	public void setDocumentoPesquisaModel(DocumentoModel documentoPesquisaModel) {
		this.documentoPesquisaModel = documentoPesquisaModel;
	}

	public List<DocumentoModel> getGrid() {
		return grid;
	}

	public void setGrid(List<DocumentoModel> grid) {
		this.grid = grid;

	}

	public void downloadPDF() throws IOException {

		// Prepare.
		FacesContext facesContext = FacesContext.getCurrentInstance();
		ExternalContext externalContext = facesContext.getExternalContext();
		HttpServletResponse response = (HttpServletResponse) externalContext.getResponse();

		File file = new File(Utilitario.getCaminhoRelatorio(), this.documentoPesquisaModel.getArquivo());
		BufferedInputStream input = null;
		BufferedOutputStream output = null;

		try {
			// Open file.
			input = new BufferedInputStream(new FileInputStream(file), DEFAULT_BUFFER_SIZE);

			// Init servlet response.
			response.reset();
			response.setHeader("Content-Type", "application/pdf");
			response.setHeader("Content-Length", String.valueOf(file.length()));
			response.setHeader("Content-Disposition", "attachment; filename=\"" + this.documentoPesquisaModel.getArquivo() + "\"");
			output = new BufferedOutputStream(response.getOutputStream(), DEFAULT_BUFFER_SIZE);

			// Write file contents to response.
			byte[] buffer = new byte[DEFAULT_BUFFER_SIZE];
			int length;
			while ((length = input.read(buffer)) > 0) {
				output.write(buffer, 0, length);
			}

			// Finalize task.
			output.flush();
		} finally {
			// Gently close streams.
			close(output);
			close(input);
		}

		facesContext.responseComplete();
	}

	private static void close(Closeable resource) {
		if (resource != null) {
			try {
				resource.close();
			} catch (IOException e) {
				// Do your thing with the exception. Print it, log it or mail
				// it. It may be useful to
				// know that this will generally only be thrown when the client
				// aborted the download.
				e.printStackTrace();
			}
		}
	}

	public void setLink(String link) {
		this.link = link;
	}

	public String getLink() {
		return link;
	}
}