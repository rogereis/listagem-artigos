/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.pesdoc.faces;

import br.com.pesdoc.dao.CrudDAO;
import br.com.pesdoc.model.CrudModel;
import br.com.pesdoc.util.Constantes;
import br.com.pesdoc.util.Utilitario;
import br.com.topsys.exception.TSApplicationException;
import br.com.topsys.util.TSUtil;
import br.com.topsys.web.faces.TSMainFaces;
import br.com.topsys.web.util.TSFacesUtil;

import java.util.List;
import org.primefaces.event.TabChangeEvent;

/**
 *
 * @author roquesouza
 */
public abstract class CrudFaces extends TSMainFaces {

  protected CrudDAO crudDAO;
  protected CrudModel crudModel;
  protected CrudModel crudPesquisaModel;
  protected boolean alterar;
  protected List<CrudModel> grid;
  private final static String ID_MSG_PESQUISA = "msgPesquisa";

  public String limpar() {
    this.alterar = false;
    this.clearFields();
    return null;
  }

  public String limparPesquisa() {
    this.clearFields();
    return null;
  }
  
  protected void validarTab(TabChangeEvent event) {
	  
      
  }

  @Override
  protected String find() {

    this.grid = this.crudDAO.pesquisar(this.crudPesquisaModel);

    TSUtil.gerarResultadoLista(grid, ID_MSG_PESQUISA);

    return null;

  }

  @Override
  protected String detail() {

    if (!TSUtil.isEmpty(this.crudModel)) {

      this.crudModel = this.crudDAO.obter(this.crudModel);

      this.alterar = true;

    }

    return SUCESSO;

  }

  @Override
  protected String insert() throws TSApplicationException {

    super.setDefaultMessage(false);

    super.setClearFields(false);

    if (!validaCampos()) {
      return Constantes.ERRO_VALIDACAO;
    }

    this.crudDAO.inserir(this.crudModel);

    this.alterar = true;
    
    TSFacesUtil.addInfoMessage("Registro inserido com sucesso.");

    super.setDefaultMessage(true);


    return null;

  }

  @Override
  protected String update() throws TSApplicationException {

    super.setClearFields(false);
    
    if (!validaCampos()) {
      return null;
    }

    this.crudDAO.alterar(this.crudModel);
    
    TSFacesUtil.addInfoMessage("Registro alterado com sucesso.");

    super.setDefaultMessage(true);

    return null;

  }

  @Override
  protected String delete() throws TSApplicationException {

    this.crudDAO.excluir(this.crudModel);
    
    TSFacesUtil.addInfoMessage("Registro excluído com sucesso.");

    return null;

  }

  protected boolean validaCampos() {
    return true;
  }

  public boolean isAlterar() {
    return alterar;
  }

  public void setAlterar(boolean alterar) {
    this.alterar = alterar;
  }

  public CrudModel getCrudModel() {
    return crudModel;
  }

  public void setCrudModel(CrudModel crudModel) {
    this.crudModel = crudModel;
  }

  public CrudModel getCrudPesquisaModel() {
    return crudPesquisaModel;
  }

  public void setCrudPesquisaModel(CrudModel crudPesquisaModel) {
    this.crudPesquisaModel = crudPesquisaModel;
  }

  public List<CrudModel> getGrid() {
    return grid;
  }

  public void setGrid(List<CrudModel> grid) {
    this.grid = grid;
  }
}
