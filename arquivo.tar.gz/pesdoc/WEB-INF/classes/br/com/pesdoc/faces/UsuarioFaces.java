package br.com.pesdoc.faces;

import br.com.pesdoc.dao.UsuarioDAO;
import br.com.pesdoc.model.CrudModel;
import br.com.pesdoc.model.UsuarioModel;
import br.com.pesdoc.util.EncriptaSenha;
import br.com.pesdoc.util.Utilitario;
import br.com.topsys.util.TSUtil;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

/**
 *
 * @author roquesouza
 */
@ManagedBean(name = "usuarioFaces")
@SessionScoped
public final class UsuarioFaces extends CrudFaces {


  public UsuarioFaces() {
    this.crudDAO = new UsuarioDAO();
    this.clearFields();
  }

  @Override
  protected void clearFields() {
    this.crudModel = new UsuarioModel();
    getCrudModel().setFlagAtivo(Boolean.TRUE);
    this.crudPesquisaModel = new UsuarioModel();
    getCrudPesquisaModel().setFlagAtivo(Boolean.TRUE);
    this.grid = new ArrayList<CrudModel>();    
  }
  
  @Override
  protected boolean validaCampos() {
    UsuarioModel model = (UsuarioModel) crudModel;
    boolean validado = true;
    if (TSUtil.isEmpty(model.getNome())) {
      validado = Utilitario.addErrorMessageObrigatorio("Nome");
    }
    if (TSUtil.isEmpty(model.getLogin())) {
      validado = Utilitario.addErrorMessageObrigatorio("Login");
    }
    if (TSUtil.isEmpty(model.getSenha())) {
      validado = Utilitario.addErrorMessageObrigatorio("Senha");
    } else {
      try {
        model.setSenha(EncriptaSenha.encriptar(model.getSenha()));
      } catch (NoSuchAlgorithmException ex) {
        Logger.getLogger(UsuarioFaces.class.getName()).log(Level.SEVERE, null, ex);
      }
    }
    
    return validado;
  }
    
  @Override
  public UsuarioModel getCrudModel() {
    return (UsuarioModel)crudModel;
  }
  
  @Override
  public UsuarioModel getCrudPesquisaModel() {
    return (UsuarioModel)crudPesquisaModel;
  }
  
}