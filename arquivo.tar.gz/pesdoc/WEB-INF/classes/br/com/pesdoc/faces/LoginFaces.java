package br.com.pesdoc.faces;


import br.com.pesdoc.dao.UsuarioDAO;
import br.com.pesdoc.model.UsuarioModel;
import br.com.pesdoc.util.Constantes;
import br.com.pesdoc.util.EncriptaSenha;
import br.com.pesdoc.util.Utilitario;
import br.com.topsys.exception.TSApplicationException;
import br.com.topsys.util.TSUtil;
import br.com.topsys.web.faces.TSMainFaces;
import br.com.topsys.web.util.TSFacesUtil;
import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.faces.bean.ManagedBean;
import javax.faces.model.SelectItem;

/**
 *
 * @author roque souza
 */
@ManagedBean(name = "loginFaces")
public final class LoginFaces extends TSMainFaces {

  private UsuarioModel usuarioModel;
  private UsuarioModel usuarioAuxiliarModel;
  private List<SelectItem> comboOrigens;
  private String novaSenha;
  private String novaSenhaConfirmacao;

  public LoginFaces() {
    this.usuarioModel = new UsuarioModel();
    this.limparNovaSenha();
  }

  public String getBanner() {          
    return  Constantes.IMAGEM_BANNER;
  }

  public String logout() throws IOException {

    TSFacesUtil.getRequest().getSession().invalidate();

    return Constantes.LOGIN;
  }

  public String acessar() {
    TSFacesUtil.getRequest().getSession().invalidate();
    
    try {
      this.usuarioModel.setSenha(EncriptaSenha.encriptar(this.usuarioModel.getSenha()));
    } catch (NoSuchAlgorithmException ex) {
      Logger.getLogger(LoginFaces.class.getName()).log(Level.SEVERE, null, ex);
      return null;
    }

    this.usuarioModel = new UsuarioDAO().obterAcesso(usuarioModel);
    if (TSUtil.isEmpty(this.usuarioModel)) {
      TSFacesUtil.addErrorMessage("Usuário e/ou Senha inválidos.");
      return null;
    }

    TSFacesUtil.addObjectInSession(Constantes.USUARIO_LOGADO, usuarioModel);

    return SUCESSO;
  }

  public String trocarSenha() throws TSApplicationException {

    UsuarioDAO usuarioDAO = new UsuarioDAO();

    if (!this.validaAlterarSenha()) {

      return null;

    }

    try {

      this.usuarioAuxiliarModel.setSenha(EncriptaSenha.encriptar(this.usuarioAuxiliarModel.getSenha()));

      this.usuarioAuxiliarModel = usuarioDAO.obterPorLoginSenha(usuarioAuxiliarModel);

      if (TSUtil.isEmpty(this.usuarioAuxiliarModel)) {

        this.addErrorMessage("Usuário e/ou Senha inválidos.");

        this.limparNovaSenha();

        return null;

      }

      this.usuarioAuxiliarModel.setSenha(EncriptaSenha.encriptar(this.novaSenha));

      usuarioDAO.alterarSenha(usuarioAuxiliarModel);

      this.limparNovaSenha();

      this.addInfoMessage("Senha alterada com sucesso!");

    } catch (NoSuchAlgorithmException ex) {

      this.addErrorMessage("Não foi possível alterar senha.");

      ex.printStackTrace();

    }

    return null;

  }

  private void limparNovaSenha() {
    this.usuarioAuxiliarModel = new UsuarioModel();
    this.novaSenha = "";
    this.novaSenhaConfirmacao = "";
  }

  private boolean validaAlterarSenha() {

    if (TSUtil.isEmpty(this.usuarioAuxiliarModel.getLogin())) {

      this.addErrorMessage("Preencha todos os campos");

      return false;

    }

    if (TSUtil.isEmpty(this.usuarioAuxiliarModel.getSenha())) {

      this.addErrorMessage("Preencha todos os campos");

      return false;

    }

    if (TSUtil.isEmpty(this.novaSenha)) {

      this.addErrorMessage("Preencha todos os campos");

      return false;

    }

    if (TSUtil.isEmpty(this.novaSenhaConfirmacao)) {

      this.addErrorMessage("Preencha todos os campos");

      return false;

    }

    if (!TSUtil.isEmpty(this.novaSenhaConfirmacao) && !TSUtil.isEmpty(this.novaSenha) && !this.novaSenha.equals(this.novaSenhaConfirmacao)) {

      this.addErrorMessage("Senhas inconsistentes");

      return false;

    }

    return true;

  }

  
  public UsuarioModel getUsuarioLogado() {
    return Utilitario.getUsuarioLogado();
  }

  public List<SelectItem> getComboOrigens() {
    return comboOrigens;
  }

  public void setComboOrigens(List<SelectItem> comboOrigens) {
    this.comboOrigens = comboOrigens;
  }

  public UsuarioModel getUsuarioModel() {
    return usuarioModel;
  }

  public void setUsuarioModel(UsuarioModel usuarioModel) {
    this.usuarioModel = usuarioModel;
  }

  public String getSobre() {
    return "SM Assessoria Empresarial & Gestão Hospitalar | Release 2.6.4";
    //incremento do release = fase.etapa.correções
  }

  public String getNovaSenha() {
    return novaSenha;
  }

  public void setNovaSenha(String novaSenha) {
    this.novaSenha = novaSenha;
  }

  public String getNovaSenhaConfirmacao() {
    return novaSenhaConfirmacao;
  }

  public void setNovaSenhaConfirmacao(String novaSenhaConfirmacao) {
    this.novaSenhaConfirmacao = novaSenhaConfirmacao;
  }

  public UsuarioModel getUsuarioAuxiliarModel() {
    return usuarioAuxiliarModel;
  }

  public void setUsuarioAuxiliarModel(UsuarioModel usuarioAuxiliarModel) {
    this.usuarioAuxiliarModel = usuarioAuxiliarModel;
  }
}
