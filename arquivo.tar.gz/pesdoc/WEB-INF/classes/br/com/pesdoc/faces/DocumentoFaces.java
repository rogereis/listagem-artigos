package br.com.pesdoc.faces;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import org.primefaces.event.FileUploadEvent;

import br.com.pesdoc.dao.DocumentoDAO;
import br.com.pesdoc.model.CrudModel;
import br.com.pesdoc.model.DocumentoModel;
import br.com.pesdoc.util.Constantes;
import br.com.pesdoc.util.ProcessaPdf;
import br.com.pesdoc.util.Utilitario;
import br.com.topsys.exception.TSApplicationException;
import br.com.topsys.util.TSUtil;
import br.com.topsys.web.util.TSFacesUtil;

/**
 *
 * @author roquesouza
 */
@ManagedBean(name = "documentoFaces")
@SessionScoped
public final class DocumentoFaces extends CrudFaces {

  private int uploaderAtivo;
  private String diretorio;

  public DocumentoFaces() {
    this.crudDAO = new DocumentoDAO();
    this.clearFields();
  }

  @Override
  protected void clearFields() {
    this.crudModel = new DocumentoModel();
    getCrudModel().setFlagAtivo(Boolean.TRUE);
    this.crudPesquisaModel = new DocumentoModel();
    getCrudPesquisaModel().setFlagAtivo(Boolean.TRUE);
    this.grid = new ArrayList<CrudModel>();
  }

  @Override
  protected boolean validaCampos() {
    DocumentoModel model = (DocumentoModel) crudModel;
    boolean validacao = true;

    if (TSUtil.isEmpty(model.getDataDocumento())) {
      validacao = Utilitario.addErrorMessageObrigatorio("Data do Documento");
    }

    if (TSUtil.isEmpty(model.getArquivo())) {
      validacao = Utilitario.addErrorMessageObrigatorio("Arquivo");
    }

    if (TSUtil.isEmpty(model.getTitulo())) {
      validacao = Utilitario.addErrorMessageObrigatorio("Título");
    }

    if (TSUtil.isEmpty(model.getTexto())) {
      validacao = Utilitario.addErrorMessageObrigatorio("Texto");
    }

    return validacao;
  }

  public String handleFileUploadArquivo(FileUploadEvent event) throws FileNotFoundException, IOException {
    getCrudModel().setArquivo(event.getFile().getFileName());

    byte[] conteudo = event.getFile().getContents();

    String arquivo = Utilitario.getCaminhoRelatorio() + getCrudModel().getArquivo();

    FileOutputStream fos = new FileOutputStream(arquivo);
    fos.write(conteudo);
    fos.close();

    getCrudModel().setTexto(Utilitario.getPdfMetaData(arquivo));
    
    if (TSUtil.isEmpty(getCrudModel().getTexto())) {
		getCrudModel().setTexto(new ProcessaPdf().processar(arquivo));
    }			

    uploaderAtivo = 0;
    
    return null;

  }

  public String importarArquivos() throws TSApplicationException {   
    
    if (TSUtil.isEmpty(Utilitario.tratarString(this.diretorio))) {
      TSFacesUtil.addErrorMessage("Preencha o campo diretório" );
      return Constantes.ERRO_VALIDACAO;
    }
    
    listFiles(new File(this.diretorio));
    return null;
  }

  private void listFiles(File diretorio) {

    String[] arquivos = diretorio.list();
    
    int cont = 0;
    
    for (int i = 0; i < arquivos.length; i++) {

      String arquivo = arquivos[i];
      
      if (".pdf".equalsIgnoreCase(arquivo.substring(arquivo.length() - 4, arquivo.length()))) {        
    	try {  
	        getCrudModel().setTexto(Utilitario.getPdfMetaData(diretorio.getAbsolutePath() + File.separator + arquivo));    	        
	        getCrudModel().setArquivo(arquivo);
	        getCrudModel().setDataDocumento(new Date());
	        getCrudModel().setTitulo(getCrudModel().getTexto().substring(0, getCrudModel().getTexto().indexOf("\n")));

			insert();
		} catch (TSApplicationException e) {
			System.out.println("Já existia o arquivo " + arquivo + " catalogado.");
		} catch (Exception e) {
			System.out.println("Erro geral arquivo: " + arquivo);
			System.out.println(e.getMessage());			
		}
      
      }
      
      
      cont = i;

    }
    
    TSFacesUtil.addInfoMessage("Importado " + cont + "arquivo(s) com sucesso.");
    
  }

  public String atualizarUploader() {
    return null;
  }

  @Override
  public DocumentoModel getCrudModel() {
    return (DocumentoModel) crudModel;
  }

  @Override
  public DocumentoModel getCrudPesquisaModel() {
    return (DocumentoModel) crudPesquisaModel;
  }

  public int getUploaderAtivo() {
    return uploaderAtivo;
  }

  public void setUploaderAtivo(int uploaderAtivo) {
    this.uploaderAtivo = uploaderAtivo;
  }

  public String getDiretorio() {
    return diretorio;
  }

  public void setDiretorio(String diretorio) {
    this.diretorio = diretorio;
  }
}