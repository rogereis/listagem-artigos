package br.com.pesdoc.faces;

import br.com.pesdoc.dao.MenuDAO;
import br.com.pesdoc.model.MenuModel;
import br.com.topsys.util.TSUtil;
import br.com.topsys.web.faces.TSMainFaces;
import br.com.topsys.web.util.TSFacesUtil;
import java.util.List;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

/**
 *
 * @author roque souza
 */
@ManagedBean(name = "menuFaces")
@SessionScoped
public final class MenuFaces extends TSMainFaces {

  private String nomeTela;
  private String tela;
  private MenuModel menuModel;
  private transient MenuDAO menuDAO;
  private List<MenuModel> menusRaiz;
  private List<MenuModel> menusCommand;
  private Integer tabAtiva;

  public MenuFaces() {
    setNomeTela("Area de Trabalho");
    this.menuDAO = new MenuDAO();
    this.menuModel = new MenuModel();
    this.menuModel.setDescricao("Area de Trabalho");
    this.menusRaiz = this.menuDAO.pesquisarMenuRaizAdm();
    this.menusCommand = this.menuDAO.pesquisarMenuCommandAdm();

    setTabAtiva(new Integer(-1));
  }

  public String redirecionar() {

    if (!TSUtil.isEmpty(this.menuModel.getManagedBean())) {
      TSFacesUtil.removeManagedBeanInSession(this.menuModel.getManagedBean());
    }

    setTela(this.menuModel.getUrl());
    setNomeTela("Area de Trabalho > " + menuModel.getMenuModel().getDescricao() + " > " + menuModel.getDescricao());
    setTabAtiva(Integer.valueOf(this.menusRaiz.indexOf(this.menuModel.getMenuModel())));
    return SUCESSO;
  }

  public String escolherMenu(MenuModel model) {
    this.menuModel = this.menusCommand.get(this.menusCommand.indexOf(model));
    return redirecionar();
  }

  public String getNomeTela() {
    return nomeTela;
  }

  public void setNomeTela(String nomeTela) {
    this.nomeTela = nomeTela;
  }

  public String getTela() {
    return tela;
  }

  public void setTela(String tela) {
    this.tela = tela;
  }

  public MenuModel getMenuModel() {
    return menuModel;
  }

  public void setMenuModel(MenuModel menuModel) {
    this.menuModel = menuModel;
  }

  public List<MenuModel> getMenusRaiz() {
    return menusRaiz;
  }

  public void setMenusRaiz(List<MenuModel> menusRaiz) {
    this.menusRaiz = menusRaiz;
  }

  public List<MenuModel> getMenusCommand() {
    return menusCommand;
  }

  public void setMenusCommand(List<MenuModel> menusCommand) {
    this.menusCommand = menusCommand;
  }

  public Integer getTabAtiva() {
    return tabAtiva;
  }

  public void setTabAtiva(Integer tabAtiva) {
    this.tabAtiva = tabAtiva;
  }

  public MenuDAO getMenuDAO() {
    return menuDAO;
  }

  public void setMenuDAO(MenuDAO menuDAO) {
    this.menuDAO = menuDAO;
  }

}
