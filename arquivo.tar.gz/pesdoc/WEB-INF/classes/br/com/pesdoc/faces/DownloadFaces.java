package br.com.pesdoc.faces;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletResponse;

import br.com.pesdoc.dao.DocumentoDAO;
import br.com.pesdoc.model.DocumentoModel;
import br.com.pesdoc.util.Utilitario;
import br.com.topsys.util.TSUtil;
import br.com.topsys.web.util.TSFacesUtil;

/**
 * 
 * @author roquesouza
 */
@ManagedBean(name = "downloadFaces")
@RequestScoped
public final class DownloadFaces {

	private DocumentoDAO documentoDAO;
	private DocumentoModel documentoPesquisaModel;
	private boolean valido;
	private static final int DEFAULT_BUFFER_SIZE = 10240; // 10KB.

	public DownloadFaces() {
		this.documentoDAO = new DocumentoDAO();
		this.clearFields();
	}

	private void clearFields() {

		String id = TSFacesUtil.getRequestParameter("id");

		try {

			this.documentoPesquisaModel = documentoDAO.obter(new DocumentoModel(new Long(id)));

			valido = (!TSUtil.isEmpty(this.documentoPesquisaModel));
			
			if (valido) {
				
				downloadPDF();
				
			}

		} catch (Exception e) {
			
			valido = false;
			
			e.printStackTrace();
			
		}

	}

	public DocumentoModel getDocumentoPesquisaModel() {
		return documentoPesquisaModel;
	}

	public void setDocumentoPesquisaModel(DocumentoModel documentoPesquisaModel) {
		this.documentoPesquisaModel = documentoPesquisaModel;
	}

	public void downloadPDF() throws IOException {

		FacesContext facesContext = FacesContext.getCurrentInstance();
		ExternalContext externalContext = facesContext.getExternalContext();
		HttpServletResponse response = (HttpServletResponse) externalContext.getResponse();

		File file = new File(Utilitario.getCaminhoRelatorio(), this.documentoPesquisaModel.getArquivo());
		BufferedInputStream input = null;
		BufferedOutputStream output = null;

		try {
			// Open file.
			input = new BufferedInputStream(new FileInputStream(file), DEFAULT_BUFFER_SIZE);

			// Init servlet response.
			response.reset();
			response.setHeader("Content-Type", "application/pdf");
			response.setHeader("Content-Length", String.valueOf(file.length()));
			response.setHeader("Content-Disposition", "attachment; filename=\"" + this.documentoPesquisaModel.getArquivo() + "\"");
			output = new BufferedOutputStream(response.getOutputStream(), DEFAULT_BUFFER_SIZE);

			// Write file contents to response.
			byte[] buffer = new byte[DEFAULT_BUFFER_SIZE];
			int length;
			while ((length = input.read(buffer)) > 0) {
				output.write(buffer, 0, length);
			}

			output.flush();
		} finally {
			close(output);
			close(input);
		}

		facesContext.responseComplete();
	}

	private static void close(Closeable resource) {
		if (resource != null) {
			try {
				resource.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	public boolean isValido() {
		return valido;
	}

	public void setValido(boolean valido) {
		this.valido = valido;
	}
}