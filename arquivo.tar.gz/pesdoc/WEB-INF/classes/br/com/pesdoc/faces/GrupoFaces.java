package br.com.pesdoc.faces;

import br.com.pesdoc.dao.GrupoDAO;
import br.com.pesdoc.model.CrudModel;
import br.com.pesdoc.model.GrupoModel;
import br.com.pesdoc.util.Utilitario;
import br.com.topsys.util.TSUtil;
import java.util.ArrayList;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

/**
 *
 * @author roquesouza
 */
@ManagedBean(name = "grupoFaces")
@SessionScoped
public final class GrupoFaces extends CrudFaces {


  public GrupoFaces() {
    this.crudDAO = new GrupoDAO();
    this.clearFields();
  }

  @Override
  protected void clearFields() {
    this.crudModel = new GrupoModel();
    getCrudModel().setFlagAtivo(Boolean.TRUE);
    this.crudPesquisaModel = new GrupoModel();
    getCrudPesquisaModel().setFlagAtivo(Boolean.TRUE);
    this.grid = new ArrayList<CrudModel>();    
  }
  
  @Override
  protected boolean validaCampos() {
    GrupoModel model = (GrupoModel) crudModel;
    if (TSUtil.isEmpty(model.getDescricao())) {
      return Utilitario.addErrorMessageObrigatorio("Descrição");
    }
    return true;
  }
    
  @Override
  public GrupoModel getCrudModel() {
    return (GrupoModel)crudModel;
  }
  
  @Override
  public GrupoModel getCrudPesquisaModel() {
    return (GrupoModel)crudPesquisaModel;
  }
  
}