/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.pesdoc.model;


import br.com.topsys.util.TSUtil;

/**
 *
 * @author roquesouza
 */
public class GrupoModel extends CrudModel {

  private Long id;
  private String descricao;
  private Boolean flagAtivo;

  public GrupoModel() {
  }
  
  public GrupoModel(Boolean flagAtivo) {
    this.flagAtivo = flagAtivo;
  }

  public GrupoModel(Long id) {
    this.id = id;
  }

  public String getDescricao() {
    this.descricao = TSUtil.tratarString(this.descricao);
    return descricao;
  }

  public void setDescricao(String descricao) {
    this.descricao = descricao;
  }

  public Long getId() {
    this.id = TSUtil.tratarLong(this.id);
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public Boolean getFlagAtivo() {
    return flagAtivo;
  }

  public void setFlagAtivo(Boolean flagAtivo) {
    this.flagAtivo = flagAtivo;
  }
  
  public String getSituacao() {
    return flagAtivo == true ? "Ativo" : "Inativo";
  }

  @Override
  public boolean equals(Object obj) {
    if (obj == null) {
      return false;
    }
    if (getClass() != obj.getClass()) {
      return false;
    }
    final GrupoModel other = (GrupoModel) obj;
    if (this.id != other.id && (this.id == null || !this.id.equals(other.id))) {
      return false;
    }
    return true;
  }

  @Override
  public int hashCode() {
    int hash = 7;
    hash = 43 * hash + (this.id != null ? this.id.hashCode() : 0);
    return hash;
  }
}
