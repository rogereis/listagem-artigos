/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.pesdoc.model;

import java.util.Date;

/**
 *
 * @author roquesouza
 */
public class DocumentoModel extends CrudModel {

  private Long id;
  private String arquivo;
  private String titulo;
  private String resumo;
  private String texto;
  private Date dataDocumento;
  private Date dataCadastro;
  private Boolean flagAtivo;

  public DocumentoModel() {
  }
  
  public DocumentoModel(Boolean flagAtivo) {
    this.flagAtivo = flagAtivo;
  }

  public DocumentoModel(Long id) {
    this.id = id;
  }

  public String getArquivo() {
    return arquivo;
  }

  public void setArquivo(String arquivo) {
    this.arquivo = arquivo;
  }

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public String getResumo() {
    return resumo;
  }

  public void setResumo(String resumo) {
    this.resumo = resumo;
  }

  public String getTexto() {
    return texto;
  }

  public void setTexto(String texto) {
    this.texto = texto;
  }

  public String getTitulo() {
    return titulo;
  }

  public void setTitulo(String titulo) {
    this.titulo = titulo;
  }

  public Date getDataCadastro() {
    return dataCadastro;
  }

  public void setDataCadastro(Date dataCadastro) {
    this.dataCadastro = dataCadastro;
  }

  public Date getDataDocumento() {
    return dataDocumento;
  }

  public void setDataDocumento(Date dataDocumento) {
    this.dataDocumento = dataDocumento;
  }

  public Boolean getFlagAtivo() {
    return flagAtivo;
  }

  public void setFlagAtivo(Boolean flagAtivo) {
    this.flagAtivo = flagAtivo;
  }
  
  public String getSituacao() {
    return flagAtivo == true ? "Ativo" : "Inativo";
  }

  @Override
  public boolean equals(Object obj) {
    if (obj == null) {
      return false;
    }
    if (getClass() != obj.getClass()) {
      return false;
    }
    final DocumentoModel other = (DocumentoModel) obj;
    if (this.id != other.id && (this.id == null || !this.id.equals(other.id))) {
      return false;
    }
    return true;
  }

  @Override
  public int hashCode() {
    int hash = 5;
    hash = 73 * hash + (this.id != null ? this.id.hashCode() : 0);
    return hash;
  }
  
}
