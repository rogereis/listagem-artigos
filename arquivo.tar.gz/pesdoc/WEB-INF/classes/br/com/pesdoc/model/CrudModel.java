/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.pesdoc.model;

import java.io.Serializable;

/**
 *
 * @author roquesouza
 */
public abstract class CrudModel implements Serializable {
  
}
