/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.pesdoc.model;

import java.io.Serializable;

/**
 *
 * @author roque souza
 */
public class MenuModel implements Serializable {

  private Long id;
  private String descricao;
  private String url;  
  private MenuModel menuModel;
  private String managedBean;    
  private Boolean flagAtivo;
  private Boolean flagInserir;
  private Boolean flagAlterar;
  private Boolean flagExcluir;  
  private Integer ordem;

  public MenuModel(String url) {
    this.url = url;
  }

  public MenuModel() {
    
  }

  public Long getId() {    
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public String getDescricao() {
    return descricao;
  }

  public void setDescricao(String descricao) {
    this.descricao = descricao;
  }

  public Boolean getFlagAtivo() {
    return flagAtivo;
  }

  public String getSituacao() {
    return flagAtivo == true ? "Ativo" : "Inativo";
  }

  public void setFlagAtivo(Boolean flagAtivo) {
    this.flagAtivo = flagAtivo;
  }  

  @Override
  public boolean equals(Object obj) {
    if (obj == null) {
      return false;
    }
    if (getClass() != obj.getClass()) {
      return false;
    }
    final MenuModel other = (MenuModel) obj;
    if (this.id != other.id && (this.id == null || !this.id.equals(other.id))) {
      return false;
    }
    return true;
  }

  @Override
  public int hashCode() {
    int hash = 7;
    hash = 67 * hash + (this.id != null ? this.id.hashCode() : 0);
    return hash;
  }

  public MenuModel getMenuModel() {
    return menuModel;
  }

  public void setMenuModel(MenuModel menuModel) {
    this.menuModel = menuModel;
  }

  public String getUrl() {
    return url;
  }

  public void setUrl(String url) {
    this.url = url;
  }

  public Boolean getFlagAlterar() {
    return flagAlterar;
  }

  public void setFlagAlterar(Boolean flagAlterar) {
    this.flagAlterar = flagAlterar;
  }

  public Boolean getFlagExcluir() {
    return flagExcluir;
  }

  public void setFlagExcluir(Boolean flagExcluir) {
    this.flagExcluir = flagExcluir;
  }

  public Boolean getFlagInserir() {
    return flagInserir;
  }

  public void setFlagInserir(Boolean flagInserir) {
    this.flagInserir = flagInserir;
  }

  public String getManagedBean() {
    return managedBean;
  }

  public void setManagedBean(String managedBean) {
    this.managedBean = managedBean;
  }

  public Integer getOrdem() {
    return ordem;
  }

  public void setOrdem(Integer ordem) {
    this.ordem = ordem;
  }
  
}
